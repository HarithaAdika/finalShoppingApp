import { Component, OnInit } from '@angular/core';
import {IAccessories} from './accessory';

import {ProductService} from '../product.service';
@Component({
  selector: 'app-accessories',
  templateUrl: './accessories.component.html',
  styleUrls: ['./accessories.component.css']
})
export class AccessoriesComponent implements OnInit {
data:any;
  Accessory:IAccessories[];

  constructor(private ProductService:ProductService,private dataService: ProductService) { }
getAccessories():void{
  this.Accessory=this.ProductService.getAccessories();
}
  ngOnInit() {
    this.getAccessories();
  }
  getAccessory(data){
 this.dataService.setUrlHistoryObj(data);
  }

}