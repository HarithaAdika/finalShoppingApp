import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {LoginpageComponent} from './loginpage/loginpage.component'
import {WelcomeComponent} from './welcome/welcome.component';
import {ProductComponent} from './product/product.component';
import {CartComponent} from './cart/cart.component';
import { RouterModule, Routes } from '@angular/router';
import {BillComponent} from './bill/bill.component'


const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginpageComponent },
  { path: 'welcome', component: WelcomeComponent },
  { path: 'product', component: ProductComponent },
  { path: 'Cart', component:CartComponent },
   { path: 'bill', component:BillComponent }
  
 
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
