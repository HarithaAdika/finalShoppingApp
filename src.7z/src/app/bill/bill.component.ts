import { Component, OnInit } from '@angular/core';
import {ProductService} from '../product.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {
datArray:any[];
sum:number=0;
d:boolean;
  constructor(private router:Router,private dataService: ProductService) {
    this.datArray= this.dataService.getUrlHistoryObj();
  
    this.cal();
   }
 cal(){
   for(let car of Array.from(this.datArray)){
       this.sum=car.price+this.sum;
     }
     console.log(this.sum);
}
logout(){
  
  this.d=confirm("ARE U SURE TO LOGOUT ...?????");
  if(this.d==true){
  this.router.navigate(['\login']);
}

}
  ngOnInit() {
  }

}
