import { Component, OnInit } from '@angular/core';
import {IElectronic} from './electronic';
import {ProductService} from '../product.service';
@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {
pageTitle="Electronics List";
data:any;
Electronics:IElectronic[];
imageWidth:number=210;
         imageMargin:number=20;
  constructor(private productService:ProductService,private dataService: ProductService ) { }
getElectronics():void{
  this.Electronics=this.productService.getElectronics();
}
  ngOnInit() {
    this.getElectronics();
  }
getElectro(data)
{
this.dataService.setUrlHistoryObj(data);
}
}
