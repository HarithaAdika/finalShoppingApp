export class Grocery {
  id: number;
  product: string;
  price:number;
  discount:string;
  imageUrl:string;
}