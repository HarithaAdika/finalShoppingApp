import { Injectable } from '@angular/core';

import {Stationary} from '../app/stationary/stationary';
import {STATIONARIES} from '../app/stationary/mock-stationary';

import { IAccessories } from "src/app/accessories/accessory";
import {ACCESSORIES} from '../app/accessories/mock-accessories';

import {Grocery} from '../app/grocery/grocery';
import {GROCERIES} from '../app/grocery/mock-grocery';

import {IElectronic} from '../app/electronics/electronic';
import {ELECTRONICS} from '../app/electronics/mock-electronics';

import {Iclothing} from '../app/clothing/cloth';
import {CLOTHING } from '../app/clothing/mock-clothing';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
getStationaries():Stationary[]{
  return STATIONARIES;
}
getAccessories():IAccessories[]{
  return ACCESSORIES;
}
getGrocery():Grocery[]{
  return GROCERIES;
}
getElectronics():IElectronic[]{
  return ELECTRONICS;
}
getCloth():Iclothing[]{
  return CLOTHING;
}

mapdata:any;
cartProducts=new Set();

  constructor() { 
    this.mapdata="";
  }

 public setUrlHistoryObj(val: any): void {
        this.mapdata = val;
this.cartProducts.add(val);
        
    }
    

    public getUrlHistoryObj(): any {
        return this.cartProducts;
    }
    public deleteArray(value){
      this.cartProducts.delete(value);
    }


}
