import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  startShopping:boolean=false;

productCategory:string[]=['Electronics','Clothing','Accessories','Stationary','Grocery'];
selectedCategory:string;
title='Shopping Cart';
  constructor(private router:Router) { }

  ngOnInit() {
  }
onSelect(prod:string):void{
  this.selectedCategory=prod;
}
showCart(){
  this.router.navigate(['Cart']);

}
}
