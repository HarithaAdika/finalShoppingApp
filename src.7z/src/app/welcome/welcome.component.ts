import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  pageTitle = "Shopping Application";
  constructor(private router:Router) { }

  ngOnInit() {
  }
  productsPage(){
    this.router.navigate(['product']);
  }

}

